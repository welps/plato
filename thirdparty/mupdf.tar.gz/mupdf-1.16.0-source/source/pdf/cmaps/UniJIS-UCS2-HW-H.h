/* This is an automatically generated file. Do not edit. */

/* UniJIS-UCS2-HW-H */

static const pdf_range cmap_UniJIS_UCS2_HW_H_ranges[] = {
{32,91,231},
{92,92,8719},
{93,126,292},
{165,165,291},
};

static pdf_cmap cmap_UniJIS_UCS2_HW_H = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniJIS-UCS2-HW-H",
	/* usecmap */ "UniJIS-UCS2-H", NULL,
	/* wmode */ 0,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	4, 4, (pdf_range*)cmap_UniJIS_UCS2_HW_H_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
