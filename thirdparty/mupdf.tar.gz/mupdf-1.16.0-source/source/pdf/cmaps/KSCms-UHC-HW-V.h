/* This is an automatically generated file. Do not edit. */

/* KSCms-UHC-HW-V */

static const pdf_range cmap_KSCms_UHC_HW_V_ranges[] = {
{41378,41379,8056},
{41381,41381,8058},
{41382,41382,8320},
{41385,41387,8059},
{41389,41389,8062},
{41394,41405,8063},
{41451,41451,8075},
{41889,41889,8076},
{41896,41897,8077},
{41900,41900,8079},
{41902,41902,8080},
{41914,41919,8081},
{41947,41947,8087},
{41949,41949,8088},
{41951,41951,8089},
{41979,41982,8090},
};

static pdf_cmap cmap_KSCms_UHC_HW_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "KSCms-UHC-HW-V",
	/* usecmap */ "KSCms-UHC-HW-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	16, 16, (pdf_range*)cmap_KSCms_UHC_HW_V_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
