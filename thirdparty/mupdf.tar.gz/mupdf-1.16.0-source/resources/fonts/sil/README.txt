This is a 'dumb' version of Charis SIL, created by taking the
plain glyphs from the design source postscript outlines and stripping
away all of the OpenType smarts and only including the basic character
set needed to cover the common Latin, Greek, and Cyrillic encodings.
