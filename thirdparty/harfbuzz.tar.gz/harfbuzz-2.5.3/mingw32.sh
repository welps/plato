#!/bin/sh
exec "$(dirname "$0")"/mingw-configure.sh i686 "$@"
